export class Channel {
    id: number;
    name: string;
}